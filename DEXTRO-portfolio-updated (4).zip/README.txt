DEXTRO website

1. Open index.html in a browser to preview the website.
2. To publish it, upload index.html to a static hosting provider.
3. Important: the contact form is a front-end demo only. It validates the fields and shows a local confirmation, but it does not send or store enquiries. Before publishing for customers, connect a trusted form backend/provider and add a real business contact route.
4. Replace any sample copy or concept portfolio items with work you have actually completed. Do not present concept samples as client projects.


Updated portfolio: added THE URBAN PLATE as an independent concept project (in progress). The project preview is illustrative and does not link to a live restaurant website.
